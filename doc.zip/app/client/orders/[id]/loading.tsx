export default function Loading() {
  return (
    <div className="container mx-auto p-4 text-center">
      <p>جاري تحميل بيانات الطلب...</p>
    </div>
  )
}
