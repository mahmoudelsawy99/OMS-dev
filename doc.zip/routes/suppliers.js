const express = require("express")
const { body, validationResult } = require("express-validator")
const Supplier = require("../models/Supplier")
const { auth, authorize } = require("../middleware/auth")

const router = express.Router()

// @route   GET /api/suppliers
// @desc    Get all suppliers
// @access  Private (Admin/Employee only)
router.get("/", [auth, authorize("GENERAL_MANAGER", "admin", "employee")], async (req, res) => {
  try {
    const page = Number.parseInt(req.query.page) || 1
    const limit = Number.parseInt(req.query.limit) || 10
    const skip = (page - 1) * limit

    const filter = {}

    // Search functionality
    if (req.query.search) {
      filter.$text = { $search: req.query.search }
    }

    // Filter by status
    if (req.query.status) {
      filter.status = req.query.status
    }

    // Filter by supplier type
    if (req.query.supplierType) {
      filter.supplierType = req.query.supplierType
    }

    const suppliers = await Supplier.find(filter)
      .populate("createdBy", "name email")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)

    const total = await Supplier.countDocuments(filter)

    res.json({
      success: true,
      data: suppliers,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
})

// @route   GET /api/suppliers/:id
// @desc    Get single supplier
// @access  Private
router.get("/:id", auth, async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id).populate("createdBy", "name email")

    if (!supplier) {
      return res.status(404).json({ message: "Supplier not found" })
    }

    res.json({ success: true, data: supplier })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
})

// @route   POST /api/suppliers
// @desc    Create new supplier
// @access  Private (Admin/Employee only)
router.post(
  "/",
  [
    auth,
    authorize("GENERAL_MANAGER", "admin", "employee"),
    body("name").trim().isLength({ min: 2 }).withMessage("Name must be at least 2 characters"),
    body("email").isEmail().withMessage("Please enter a valid email"),
    body("phone").isMobilePhone().withMessage("Please enter a valid phone number"),
    body("address.street").notEmpty().withMessage("Street address is required"),
    body("address.city").notEmpty().withMessage("City is required"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      // Check if supplier with email already exists
      const existingSupplier = await Supplier.findOne({ email: req.body.email })
      if (existingSupplier) {
        return res.status(400).json({ message: "Supplier with this email already exists" })
      }

      const supplier = new Supplier({
        ...req.body,
        createdBy: req.user.id,
      })

      await supplier.save()
      await supplier.populate("createdBy", "name email")

      res.status(201).json({ success: true, data: supplier })
    } catch (error) {
      console.error(error)
      res.status(500).json({ message: "Server error" })
    }
  },
)

// @route   PUT /api/suppliers/:id
// @desc    Update supplier
// @access  Private (Admin/Employee only)
router.put("/:id", [auth, authorize("GENERAL_MANAGER", "admin", "employee")], async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id)

    if (!supplier) {
      return res.status(404).json({ message: "Supplier not found" })
    }

    const updatedSupplier = await Supplier.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate("createdBy", "name email")

    res.json({ success: true, data: updatedSupplier })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
})

// @route   DELETE /api/suppliers/:id
// @desc    Delete supplier
// @access  Private (Admin only)
router.delete("/:id", [auth, authorize("GENERAL_MANAGER", "admin")], async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id)

    if (!supplier) {
      return res.status(404).json({ message: "Supplier not found" })
    }

    await Supplier.findByIdAndDelete(req.params.id)
    res.json({ success: true, message: "Supplier deleted successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
})

module.exports = router 